import MainController from "./controllers/MainController.js";
import "./app.scss";

document.addEventListener("DOMContentLoaded", () => {
  new MainController();
});
