import * as React from 'react';
import './Name.css';

const Name = () => <span className="Name">World</span>;

export default Name;