import * as React from 'react';
import * as ReactDOM from 'react-dom';

import Hello from "./Hello.js";

ReactDOM.render(
  <Hello />, 
  document.getElementById("root")
);
