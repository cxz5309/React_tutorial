module.exports = {
  presets: [
    // TODO: 리액트 프리셋을 추가하세요.
    "@babel/preset-react"
  ],
  plugins: [
    // TODO: 리액트 핫로더 플러그인을 추가하세요.
    "react-hot-loader/babel"
  ]
};
